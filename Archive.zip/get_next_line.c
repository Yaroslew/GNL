/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pcorlys- <pcorlys-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/01/26 06:55:39 by pcorlys-          #+#    #+#             */
/*   Updated: 2019/01/29 06:55:49 by pcorlys-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

static void			save_str(t_lst *node, char *temp, size_t size, size_t start)
{
	char			*copy;

	if (size == 0)
	{
		ft_strdel(&node->str);
		node->size = 0;
		return ;
	}
	copy = node->str;
	node->str = ft_strsub(temp, (unsigned int)start, size);
	node->size = size;
	ft_strdel(&copy);
}

static int			reader(int fd, char **line, t_lst *node)
{
	int				read_file;
	char			*temp;
	size_t			q;

	q = 0;
	temp = ft_memalloc(BUFF_SIZE);
	if ((read_file = read(fd, temp, BUFF_SIZE)) == 0)
		return (0);
	if (read_file < 0)
		return (-1);
	while (temp[q] != '\n' && temp[q])
		q++;
	if (temp[q] == '\n' || BUFF_SIZE > read_file)
	{
		*line = ft_strnjoin(line, temp, q);
		if (temp[q] == '\n')
			save_str(node, temp, ft_strlen(temp) - (q + 1), (q + 1));
		if (BUFF_SIZE > read_file && temp[q] != '\n')
			save_str(node, temp, 0, 0);
		ft_strdel(&temp);
		return (1);
	}
	*line = ft_strnjoin(line, temp, q);
	ft_strdel(&temp);
	return (reader(fd, line, node));
}

static int			the_rest_of_line(t_lst *node, char **line)
{
	size_t			q;
	int				flag;

	q = 0;
	flag = 0;
	while (node->str[q] != '\n' && node->str[q])
		q++;
	if (node->str[q] == '\n')
		flag++;
	*line = ft_strnjoin(line, node->str, q);
	if (node->str[q] == '\n' || node->str[0] == '\n')
		save_str(node, node->str, node->size - (q + 1), q + 1);
	return (flag);
}

static t_lst		*create_search_node(int fd)
{
	t_lst			*temp;
	static t_lst	*head;

	temp = head;
	while (temp)
	{
		if (temp->fd == fd)
			return (temp);
		temp = temp->next;
	}
	if (!(temp = malloc(sizeof(t_lst))))
		return (NULL);
	temp->str = NULL;
	temp->size = 0;
	temp->fd = fd;
	temp->next = head;
	head = temp;
	return (temp);
}

int					get_next_line(const int fd, char **line)
{
	t_lst			*node;
	int				res;
	int				sum;
	char			*result;

	if ((res = 0) || fd == 2 || fd == 1 || fd < 0 || BUFF_SIZE < 1 || !line)
		return (-1);
	result = NULL;
	node = create_search_node(fd);
	if (node->size)
		res = the_rest_of_line(node, &result);
	*line = result;
	if (res)
		return (1);
	sum = reader(fd, &result, node);
	*line = result;
	if (sum == 0 && node->size > 0)
	{
		sum = 1;
		ft_strdel(&node->str);
		node->size = 0;
	}
	if (sum == 0)
		node->fd = -1;
	return (sum);
}
